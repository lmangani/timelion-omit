var alter = require('../../../src/core_plugins/timelion/server/lib/alter.js')
var Datasource = require('../../../src/core_plugins/timelion/server/lib/classes/datasource')
var _ = require('lodash')

module.exports = new Datasource('omit', {
  args: [
    {
      name: 'inputSeries',
      types: ['seriesList']
    }
  ],
  help: 'Omit nulls values from series output.',

  fn: function omitFn (args, tlConfig) {
    var config = args.byName;

    return alter(args, function (eachSeries) {

      var data = _.filter(eachSeries.data, function(point) {
        return point[1] != null;
      });
      eachSeries.data = data;

      return eachSeries;
    });
  }

})
